# 🧠 Ulugbek AI

O'zbek tilidagi to'liq stack AI platforma — React + Express + PostgreSQL + Clerk Auth.

---

## Tech Stack

- **Monorepo**: pnpm workspaces
- **Frontend**: React 18, Vite, Tailwind CSS v4, wouter (routing)
- **Auth**: Clerk (Google OAuth only)
- **Backend**: Express 5, TypeScript
- **Database**: PostgreSQL + Drizzle ORM
- **AI Providers**: Groq, OpenAI, Anthropic, Google Gemini

---

## Monorepo Structure

```
ulugbek-ai/
├── artifacts/
│   ├── web-app/          → React + Vite frontend (port 5173)
│   └── api-server/       → Express API server (port 8080)
└── lib/
    ├── db/               → PostgreSQL schema + Drizzle ORM
    ├── api-spec/         → OpenAPI YAML spec
    └── api-client-react/ → Orval-generated React Query hooks
```

---

## Quick Start

### 1. Prerequisites

- Node.js 18+
- pnpm (`npm install -g pnpm`)
- PostgreSQL database running

### 2. Clone & Install

```bash
git clone <repo-url>
cd ulugbek-ai
pnpm install
```

### 3. Setup Environment Variables

**API Server** (`artifacts/api-server/.env`):
```env
DATABASE_URL=postgresql://user:password@localhost:5432/ulugbek_ai
CLERK_SECRET_KEY=sk_test_...
FRONTEND_URL=http://localhost:5173
SESSION_SECRET=change-this-secret
```

**Frontend** (`artifacts/web-app/.env`):
```env
VITE_CLERK_PUBLISHABLE_KEY=pk_test_...
```

### 4. Clerk Setup

1. Go to [dashboard.clerk.com](https://dashboard.clerk.com)
2. Create a new application
3. Enable **Google** as the only OAuth provider
4. Copy the Publishable Key → `VITE_CLERK_PUBLISHABLE_KEY`
5. Copy the Secret Key → `CLERK_SECRET_KEY`
6. In Clerk dashboard → Sessions → Add `email` and `name` to session claims

### 5. Database Setup

```bash
# Push schema to PostgreSQL
pnpm db:push

# (Optional) Seed initial plans
```

Seed the plans table manually:
```sql
INSERT INTO plans (tier, name, price, features) VALUES
  ('free', 'Free', '0', ARRAY['Cheksiz chat', '1 rasm', '1 video']),
  ('pro', 'Pro', '9.99', ARRAY['Hamma narsa cheksiz', 'API kirish']);
```

### 6. Run Development

```bash
# Run both frontend + backend concurrently
pnpm dev

# Or individually:
pnpm --filter api-server dev    # http://localhost:8080
pnpm --filter web-app dev       # http://localhost:5173
```

---

## AI Provider Setup (Admin Panel)

After your first login with an admin email, go to `/admin` → **AI Provayderlar** tab.

1. Expand a provider card (e.g., Groq)
2. Select a model (e.g., `llama-3.3-70b-versatile`)
3. Set feature to `chat`
4. Enter your API key
5. Click **Saqlash**

The first active `chat` config will be used for all AI responses.

### Getting API Keys

| Provider | Console URL |
|----------|-------------|
| Groq | https://console.groq.com/keys |
| OpenAI | https://platform.openai.com/api-keys |
| Anthropic | https://console.anthropic.com/settings/keys |
| Google Gemini | https://aistudio.google.com/app/apikey |

---

## Admin Access

Admin emails are hardcoded SERVER-SIDE ONLY in `artifacts/api-server/src/middleware/auth.ts`:

```typescript
const ADMIN_EMAILS = ['tuevulugbek1991@gmail.com', 'globjournal@gmail.com'];
```

These users automatically get `role='admin'` on first login. The email list is never exposed to the frontend.

---

## API Routes

### Public
- `GET /api/plans` — All subscription plans

### Authenticated
- `GET /api/me` — Current user profile
- `GET /api/conversations` — User's conversations
- `POST /api/conversations` — Create conversation
- `DELETE /api/conversations/:id` — Delete conversation
- `GET /api/conversations/:id/messages` — Get messages
- `POST /api/conversations/:id/messages` — Send message + get AI reply
- `POST /api/ai/complete` — Direct AI completion
- `GET /api/usage` — Usage stats

### Admin Only
- `GET /api/admin/stats` — Platform statistics
- `GET /api/admin/users` — Paginated users
- `PUT /api/admin/users/:id` — Update user role/tier
- `GET /api/admin/api-configs` — AI provider configs
- `POST /api/admin/api-configs` — Add AI config
- `DELETE /api/admin/api-configs/:id` — Delete config
- `PUT /api/admin/plans/:tier` — Update plan
- `GET /api/admin/logs` — Activity logs

---

## Chat Agents

| Agent ID | Description |
|----------|-------------|
| `chat` | Umumiy yordamchi |
| `code` | Dasturlash mutaxassisi |
| `bank` | Bank operatori |
| `gov` | Davlat xizmatlari |
| `doctor` | Tibbiy ma'lumot |
| `lawyer` | Huquqiy maslahat |
| `translate` | Tarjimon |
| `social` | SMM mutaxassis |
| `money` | Online daromad |
| `edu` | O'qituvchi |

---

## Build for Production

```bash
# Build all packages
pnpm build

# Start API server
cd artifacts/api-server && node dist/index.cjs

# Serve frontend (use nginx or similar)
cd artifacts/web-app && pnpm preview
```

---

## After Schema Changes

```bash
pnpm db:push       # Push schema changes to DB
```

## After OpenAPI Changes

```bash
pnpm codegen       # Regenerate React Query hooks from openapi.yaml
```

---

## Free vs Pro Limits

| Feature | Free | Pro |
|---------|------|-----|
| Chat | Unlimited | Unlimited |
| Image analysis | 1 | Unlimited |
| Video | 1 | Unlimited |
| File uploads | 1 | Unlimited |

Usage is tracked in the `usage` table per user per feature.
