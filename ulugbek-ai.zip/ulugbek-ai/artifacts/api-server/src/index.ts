import express from 'express';
import cors from 'cors';
import pinoHttp from 'pino-http';
import { logger } from './logger.js';
import { clerkAuth, requireAuth, getOrCreateUser, requireAdmin } from './middleware/auth.js';
import userRoutes from './routes/user.js';
import conversationRoutes from './routes/conversations.js';
import aiRoutes from './routes/ai.js';
import planRoutes from './routes/plans.js';
import adminRoutes from './routes/admin.js';

const app = express();
const PORT = 8080;

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true,
}));
app.use(express.json());
app.use(pinoHttp({ logger }));

// Clerk auth (adds req.auth to all requests)
app.use(clerkAuth);

// Public routes
app.get('/api/plans', planRoutes);

// Protected routes - require auth
app.use('/api/me', requireAuth, getOrCreateUser, userRoutes);
app.use('/api/usage', requireAuth, getOrCreateUser, userRoutes);
app.use('/api/conversations', requireAuth, getOrCreateUser, conversationRoutes);
app.use('/api/ai', requireAuth, getOrCreateUser, aiRoutes);

// Admin routes
app.use('/api/admin', requireAuth, getOrCreateUser, requireAdmin, adminRoutes);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Error handler
app.use((err: any, req: any, res: any, next: any) => {
  logger.error(err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal Server Error',
  });
});

app.listen(PORT, () => {
  logger.info(`API server running on port ${PORT}`);
});

export default app;
