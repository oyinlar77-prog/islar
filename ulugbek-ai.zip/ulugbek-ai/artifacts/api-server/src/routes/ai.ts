import { Router } from 'express';
import { callAI } from '../ai-service.js';
import { logger } from '../logger.js';

const router = Router();

// POST /api/ai/complete
router.post('/complete', async (req, res) => {
  const user = (req as any).user;
  const { messages, agentId, conversationId } = req.body;

  if (!messages || !Array.isArray(messages)) {
    res.status(400).json({ error: 'messages array is required' });
    return;
  }

  try {
    const content = await callAI(messages, agentId, user.id);
    res.json({ content });
  } catch (error) {
    logger.error(error, 'AI complete error');
    res.status(500).json({ error: 'AI service error. Please configure an AI provider.' });
  }
});

export default router;
