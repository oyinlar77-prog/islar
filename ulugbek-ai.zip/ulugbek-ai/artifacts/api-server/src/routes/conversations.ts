import { Router } from 'express';
import { db, conversations, messages, activityLogs } from 'lib-db';
import { eq, and, desc } from 'drizzle-orm';
import { callAI } from '../ai-service.js';
import { logger } from '../logger.js';

const router = Router();

// GET /api/conversations
router.get('/', async (req, res) => {
  const user = (req as any).user;
  const convs = await db
    .select()
    .from(conversations)
    .where(eq(conversations.userId, user.id))
    .orderBy(desc(conversations.updatedAt));
  res.json(convs);
});

// POST /api/conversations
router.post('/', async (req, res) => {
  const user = (req as any).user;
  const { title } = req.body;
  const [conv] = await db
    .insert(conversations)
    .values({ userId: user.id, title: title || 'New Conversation' })
    .returning();
  res.status(201).json(conv);
});

// DELETE /api/conversations/:id
router.delete('/:id', async (req, res) => {
  const user = (req as any).user;
  const id = parseInt(req.params.id);

  const conv = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, user.id)))
    .limit(1);

  if (conv.length === 0) {
    res.status(404).json({ error: 'Conversation not found' });
    return;
  }

  // Delete messages first
  await db.delete(messages).where(eq(messages.conversationId, id));
  await db.delete(conversations).where(eq(conversations.id, id));
  res.json({ success: true });
});

// GET /api/conversations/:id/messages
router.get('/:id/messages', async (req, res) => {
  const user = (req as any).user;
  const id = parseInt(req.params.id);

  const conv = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, user.id)))
    .limit(1);

  if (conv.length === 0) {
    res.status(404).json({ error: 'Conversation not found' });
    return;
  }

  const msgs = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(messages.createdAt);

  res.json(msgs);
});

// POST /api/conversations/:id/messages
router.post('/:id/messages', async (req, res) => {
  const user = (req as any).user;
  const id = parseInt(req.params.id);
  const { content, agentId } = req.body;

  if (!content) {
    res.status(400).json({ error: 'Content is required' });
    return;
  }

  const conv = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, user.id)))
    .limit(1);

  if (conv.length === 0) {
    res.status(404).json({ error: 'Conversation not found' });
    return;
  }

  // Save user message
  const [userMsg] = await db.insert(messages).values({
    conversationId: id,
    role: 'user',
    content,
  }).returning();

  // Get conversation history
  const history = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(messages.createdAt);

  const chatHistory = history.map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }));

  try {
    const aiContent = await callAI(chatHistory, agentId, user.id);

    const [assistantMsg] = await db.insert(messages).values({
      conversationId: id,
      role: 'assistant',
      content: aiContent,
    }).returning();

    // Update conversation timestamp
    await db.update(conversations)
      .set({ updatedAt: new Date() })
      .where(eq(conversations.id, id));

    res.json(assistantMsg);
  } catch (error) {
    logger.error(error, 'AI error in send message');
    res.status(500).json({ error: 'AI service error. Please configure an AI provider.' });
  }
});

export default router;
