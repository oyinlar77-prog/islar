import { Router } from 'express';
import { db, plans } from 'lib-db';

const router = Router();

// GET /api/plans (public)
router.get('/', async (req, res) => {
  const allPlans = await db.select().from(plans);
  res.json(allPlans);
});

export default router;
