import { Router } from 'express';
import { db, users, conversations, messages, apiConfigs, plans, activityLogs } from 'lib-db';
import { eq, ilike, count, or, desc } from 'drizzle-orm';
import { logger } from '../logger.js';

const router = Router();

// GET /api/admin/stats
router.get('/stats', async (req, res) => {
  const [totalUsersResult] = await db.select({ count: count() }).from(users);
  const [proUsersResult] = await db.select({ count: count() }).from(users).where(eq(users.tier, 'pro'));
  const [freeUsersResult] = await db.select({ count: count() }).from(users).where(eq(users.tier, 'free'));
  const [totalConvsResult] = await db.select({ count: count() }).from(conversations);
  const [totalMsgsResult] = await db.select({ count: count() }).from(messages);

  res.json({
    totalUsers: Number(totalUsersResult.count),
    proUsers: Number(proUsersResult.count),
    freeUsers: Number(freeUsersResult.count),
    totalConversations: Number(totalConvsResult.count),
    totalMessages: Number(totalMsgsResult.count),
  });
});

// GET /api/admin/users
router.get('/users', async (req, res) => {
  const page = parseInt(req.query.page as string) || 1;
  const limit = parseInt(req.query.limit as string) || 20;
  const search = req.query.search as string;

  const offset = (page - 1) * limit;

  let query = db.select().from(users);

  if (search) {
    query = query.where(
      or(ilike(users.email, `%${search}%`), ilike(users.name as any, `%${search}%`))
    ) as any;
  }

  const allUsers = await (query as any).limit(limit).offset(offset).orderBy(desc(users.createdAt));
  const [totalResult] = await db.select({ count: count() }).from(users);

  res.json({ users: allUsers, total: Number(totalResult.count) });
});

// PUT /api/admin/users/:id
router.put('/users/:id', async (req, res) => {
  const id = parseInt(req.params.id);
  const { role, tier } = req.body;

  const updates: Record<string, any> = { updatedAt: new Date() };
  if (role) updates.role = role;
  if (tier) updates.tier = tier;

  const [updated] = await db.update(users).set(updates).where(eq(users.id, id)).returning();

  if (!updated) {
    res.status(404).json({ error: 'User not found' });
    return;
  }

  res.json(updated);
});

// GET /api/admin/api-configs
router.get('/api-configs', async (req, res) => {
  const configs = await db.select().from(apiConfigs);
  // Mask API keys partially
  const masked = configs.map(c => ({
    ...c,
    apiKey: c.apiKey ? `${c.apiKey.slice(0, 8)}...` : null,
  }));
  res.json(masked);
});

// POST /api/admin/api-configs
router.post('/api-configs', async (req, res) => {
  const { feature, provider, model, apiKey } = req.body;

  if (!feature || !provider || !model) {
    res.status(400).json({ error: 'feature, provider, and model are required' });
    return;
  }

  const [config] = await db.insert(apiConfigs).values({
    feature,
    provider,
    model,
    apiKey,
    isActive: true,
  }).returning();

  // Log activity
  await db.insert(activityLogs).values({
    userId: (req as any).user.id,
    userEmail: (req as any).user.email,
    type: 'api_config_created',
    description: `New ${provider} config added for feature: ${feature}`,
  });

  res.status(201).json({ ...config, apiKey: config.apiKey ? `${config.apiKey.slice(0, 8)}...` : null });
});

// DELETE /api/admin/api-configs/:id
router.delete('/api-configs/:id', async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(apiConfigs).where(eq(apiConfigs.id, id));
  res.json({ success: true });
});

// PUT /api/admin/plans/:tier
router.put('/plans/:tier', async (req, res) => {
  const { tier } = req.params;
  const { name, price } = req.body;

  const updates: Record<string, any> = {};
  if (name) updates.name = name;
  if (price !== undefined) updates.price = price;

  const [updated] = await db.update(plans).set(updates).where(eq(plans.tier, tier)).returning();

  if (!updated) {
    // Create if not exists
    const [created] = await db.insert(plans).values({ tier, name: name || tier, price: price || '0' }).returning();
    res.json(created);
    return;
  }

  res.json(updated);
});

// GET /api/admin/logs
router.get('/logs', async (req, res) => {
  const page = parseInt(req.query.page as string) || 1;
  const limit = parseInt(req.query.limit as string) || 20;
  const offset = (page - 1) * limit;

  const logs = await db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(limit).offset(offset);
  const [totalResult] = await db.select({ count: count() }).from(activityLogs);

  res.json({ logs, total: Number(totalResult.count) });
});

export default router;
