import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ClerkProvider, SignIn, useAuth } from '@clerk/clerk-react';
import { Route, Switch, useLocation } from 'wouter';
import LandingPage from './pages/LandingPage';
import ChatPage from './pages/ChatPage';
import AdminPage from './pages/AdminPage';
import SettingsPage from './pages/SettingsPage';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      retry: 1,
    },
  },
});

const CLERK_KEY = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY;

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isSignedIn, isLoaded } = useAuth();
  const [, navigate] = useLocation();

  if (!isLoaded) {
    return (
      <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#080d1a' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{
            width: 48, height: 48, borderRadius: 14, background: 'linear-gradient(135deg, #6366f1, #818cf8)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, margin: '0 auto 16px',
          }}>🧠</div>
          <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 14 }}>Yuklanmoqda...</div>
        </div>
      </div>
    );
  }

  if (!isSignedIn) {
    return (
      <div style={{
        height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: '#080d1a',
      }}>
        <div style={{ textAlign: 'center' }}>
          <SignIn
            routing="hash"
            appearance={{
              variables: {
                colorBackground: '#0d1526',
                colorText: '#e2e8f0',
                colorPrimary: '#6366f1',
                colorInputBackground: 'rgba(255,255,255,0.06)',
                colorInputText: '#e2e8f0',
                borderRadius: '12px',
              },
              elements: {
                card: { boxShadow: 'none', border: '1px solid rgba(255,255,255,0.1)' },
              },
            }}
          />
        </div>
      </div>
    );
  }

  return <>{children}</>;
}

function AppRoutes() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/chat">
        <ProtectedRoute>
          <ChatPage />
        </ProtectedRoute>
      </Route>
      <Route path="/admin">
        <ProtectedRoute>
          <AdminPage />
        </ProtectedRoute>
      </Route>
      <Route path="/settings">
        <ProtectedRoute>
          <SettingsPage />
        </ProtectedRoute>
      </Route>
      <Route>
        <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#080d1a' }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 64, marginBottom: 16 }}>404</div>
            <div style={{ color: 'rgba(255,255,255,0.4)', marginBottom: 24 }}>Sahifa topilmadi</div>
            <a href="/" style={{ color: '#818cf8', textDecoration: 'none', fontSize: 14 }}>← Bosh sahifaga</a>
          </div>
        </div>
      </Route>
    </Switch>
  );
}

export default function App() {
  return (
    <ClerkProvider publishableKey={CLERK_KEY}>
      <QueryClientProvider client={queryClient}>
        <AppRoutes />
      </QueryClientProvider>
    </ClerkProvider>
  );
}
