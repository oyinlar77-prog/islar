import { useState } from 'react';
import { useLocation } from 'wouter';
import {
  useMe, useAdminStats, useAdminUsers, useUpdateUser, useApiConfigs,
  useCreateApiConfig, useDeleteApiConfig, usePlans, useUpdatePlan, useAdminLogs,
} from '../hooks/api';

const PROVIDERS = [
  {
    id: 'groq', name: 'Groq', icon: '⚡', color: '#f55036',
    models: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'llama3-70b-8192', 'mixtral-8x7b-32768', 'gemma2-9b-it'],
    keyUrl: 'https://console.groq.com/keys',
  },
  {
    id: 'gemini', name: 'Google Gemini', icon: '✦', color: '#4285f4',
    models: ['gemini-2.0-flash', 'gemini-1.5-pro', 'gemini-1.5-flash', 'gemini-1.5-flash-8b'],
    keyUrl: 'https://aistudio.google.com/app/apikey',
  },
  {
    id: 'openai', name: 'OpenAI / GPT', icon: '◆', color: '#10a37f',
    models: ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-4', 'gpt-3.5-turbo'],
    keyUrl: 'https://platform.openai.com/api-keys',
  },
  {
    id: 'anthropic', name: 'Anthropic / Claude', icon: '▲', color: '#cc785c',
    models: ['claude-3-5-sonnet-20241022', 'claude-3-5-haiku-20241022', 'claude-3-opus-20240229', 'claude-3-haiku-20240307'],
    keyUrl: 'https://console.anthropic.com/settings/keys',
  },
];

const FEATURES = ['chat', 'image_analysis', 'video', 'translation', 'code'];

const ADMIN_TABS = [
  { id: 'stats', label: '📊 Umumiy' },
  { id: 'users', label: '👥 Foydalanuvchilar' },
  { id: 'ai', label: '🔑 AI Provayderlar' },
  { id: 'plans', label: '💎 Rejalar' },
  { id: 'logs', label: '📋 Loglar' },
];

function ProviderCard({ provider, configs, onAdd, onDelete }: any) {
  const [expanded, setExpanded] = useState(false);
  const [showKey, setShowKey] = useState(false);
  const [form, setForm] = useState({ model: provider.models[0], feature: 'chat', apiKey: '' });

  const myConfigs = configs?.filter((c: any) => c.provider === provider.id) || [];

  return (
    <div style={{
      borderRadius: 16, border: `1px solid ${expanded ? provider.color + '40' : 'rgba(255,255,255,0.08)'}`,
      background: 'rgba(255,255,255,0.03)', overflow: 'hidden', transition: 'all 0.2s',
    }}>
      {/* Header */}
      <div
        onClick={() => setExpanded(!expanded)}
        style={{
          padding: '16px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          cursor: 'pointer', borderBottom: expanded ? '1px solid rgba(255,255,255,0.06)' : 'none',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 40, height: 40, borderRadius: 10, display: 'flex', alignItems: 'center',
            justifyContent: 'center', fontSize: 20, background: provider.color + '20',
            border: `1px solid ${provider.color}40`,
          }}>{provider.icon}</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15 }}>{provider.name}</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>{myConfigs.length} ta sozlama</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {myConfigs.length > 0 && (
            <span style={{
              padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600,
              background: provider.color + '20', color: provider.color,
            }}>{myConfigs.length} aktiv</span>
          )}
          <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: 18 }}>{expanded ? '▲' : '▼'}</span>
        </div>
      </div>

      {expanded && (
        <div style={{ padding: 20 }}>
          {/* Existing configs */}
          {myConfigs.length > 0 && (
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', marginBottom: 8 }}>SOZLANGAN MODELLAR</div>
              {myConfigs.map((c: any) => (
                <div key={c.id} style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '10px 14px', borderRadius: 10, background: 'rgba(255,255,255,0.04)',
                  border: '1px solid rgba(255,255,255,0.06)', marginBottom: 6,
                }}>
                  <div>
                    <span style={{ fontFamily: 'monospace', fontSize: 13, color: provider.color }}>{c.model}</span>
                    <span style={{ marginLeft: 8, fontSize: 11, color: 'rgba(255,255,255,0.3)', background: 'rgba(255,255,255,0.06)', padding: '2px 6px', borderRadius: 4 }}>{c.feature}</span>
                  </div>
                  <button onClick={() => onDelete(c.id)} style={{
                    padding: '4px 10px', borderRadius: 6, fontSize: 12,
                    background: 'rgba(248,113,113,0.15)', color: '#f87171',
                    border: '1px solid rgba(248,113,113,0.2)', cursor: 'pointer',
                  }}>O'chirish</button>
                </div>
              ))}
            </div>
          )}

          {/* Add form */}
          <div style={{ background: 'rgba(255,255,255,0.03)', borderRadius: 12, padding: 16, border: '1px solid rgba(255,255,255,0.06)' }}>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', marginBottom: 12 }}>YANGI QO'SHISH</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
              <select
                value={form.model}
                onChange={e => setForm({ ...form, model: e.target.value })}
                style={{ padding: '10px', borderRadius: 10, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: '#e2e8f0', fontSize: 13 }}
              >
                {provider.models.map((m: string) => <option key={m} value={m}>{m}</option>)}
              </select>
              <select
                value={form.feature}
                onChange={e => setForm({ ...form, feature: e.target.value })}
                style={{ padding: '10px', borderRadius: 10, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: '#e2e8f0', fontSize: 13 }}
              >
                {FEATURES.map(f => <option key={f} value={f}>{f}</option>)}
              </select>
            </div>
            <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
              <input
                type={showKey ? 'text' : 'password'}
                value={form.apiKey}
                onChange={e => setForm({ ...form, apiKey: e.target.value })}
                placeholder="API kalitini kiriting..."
                style={{
                  flex: 1, padding: '10px 14px', borderRadius: 10,
                  background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)',
                  color: '#e2e8f0', fontSize: 13, outline: 'none',
                }}
              />
              <button onClick={() => setShowKey(!showKey)} style={{
                padding: '10px 14px', borderRadius: 10, background: 'rgba(255,255,255,0.06)',
                border: '1px solid rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.5)', cursor: 'pointer', fontSize: 14,
              }}>{showKey ? '🙈' : '👁'}</button>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <button
                onClick={() => onAdd({ provider: provider.id, ...form })}
                className="btn-gradient"
                style={{ padding: '10px 20px', fontSize: 13 }}
              >Saqlash</button>
              <a href={provider.keyUrl} target="_blank" rel="noreferrer" style={{ fontSize: 12, color: provider.color, textDecoration: 'none' }}>
                🔗 API kalitini olish →
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function AdminPage() {
  const { data: user, isLoading } = useMe();
  const [, navigate] = useLocation();
  const [tab, setTab] = useState('stats');
  const [userSearch, setUserSearch] = useState('');
  const [userPage, setUserPage] = useState(1);
  const [logPage, setLogPage] = useState(1);

  const { data: stats } = useAdminStats();
  const { data: usersData } = useAdminUsers(userPage, userSearch);
  const updateUser = useUpdateUser();
  const { data: configs } = useApiConfigs();
  const createConfig = useCreateApiConfig();
  const deleteConfig = useDeleteApiConfig();
  const { data: plans } = usePlans();
  const updatePlan = useUpdatePlan();
  const { data: logsData } = useAdminLogs(logPage);

  if (isLoading) return <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', background: '#080d1a', color: '#e2e8f0' }}>Yuklanmoqda...</div>;

  if (user?.role !== 'admin') {
    navigate('/chat');
    return null;
  }

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: '#080d1a', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '16px 24px', borderBottom: '1px solid rgba(255,255,255,0.06)',
        background: 'rgba(8,13,26,0.95)', backdropFilter: 'blur(20px)', flexShrink: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button onClick={() => navigate('/chat')} style={{
            padding: '8px 12px', borderRadius: 10, border: 'none',
            background: 'rgba(255,255,255,0.06)', color: '#e2e8f0', cursor: 'pointer',
          }}>← Orqaga</button>
          <h1 style={{ fontSize: 18, fontWeight: 700 }}>🔴 Admin Panel</h1>
        </div>
        <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>{user?.email}</span>
      </div>

      {/* Tab bar */}
      <div style={{ padding: '8px 16px', borderBottom: '1px solid rgba(255,255,255,0.06)', flexShrink: 0 }}>
        <div className="tab-bar">
          {ADMIN_TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} className={`tab-item ${tab === t.id ? 'active' : ''}`}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 20 }}>
        {/* Stats */}
        {tab === 'stats' && stats && (
          <div className="animate-fadeIn">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16, marginBottom: 24 }}>
              {[
                { label: 'Jami foydalanuvchilar', value: stats.totalUsers, icon: '👥', color: '#6366f1' },
                { label: 'Pro foydalanuvchilar', value: stats.proUsers, icon: '💎', color: '#34d399' },
                { label: 'Free foydalanuvchilar', value: stats.freeUsers, icon: '🆓', color: '#818cf8' },
                { label: 'Suhbatlar', value: stats.totalConversations, icon: '💬', color: '#fbbf24' },
                { label: 'Xabarlar', value: stats.totalMessages, icon: '📨', color: '#f87171' },
              ].map(s => (
                <div key={s.label} className="glass-card" style={{ padding: 20 }}>
                  <div style={{ fontSize: 28, marginBottom: 8 }}>{s.icon}</div>
                  <div style={{ fontSize: 28, fontWeight: 800, color: s.color }}>{s.value}</div>
                  <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.4)', marginTop: 4 }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Users */}
        {tab === 'users' && (
          <div className="animate-fadeIn">
            <div style={{ marginBottom: 16 }}>
              <input
                value={userSearch}
                onChange={e => { setUserSearch(e.target.value); setUserPage(1); }}
                placeholder="Email bo'yicha qidiring..."
                style={{
                  width: '100%', maxWidth: 400, padding: '10px 16px', borderRadius: 12,
                  background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)',
                  color: '#e2e8f0', fontSize: 14, outline: 'none',
                }}
              />
            </div>
            <div className="glass-card" style={{ overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                    {['Email', 'Ism', 'Sana', 'Rol', 'Tarif'].map(h => (
                      <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontSize: 12, color: 'rgba(255,255,255,0.4)', fontWeight: 600 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {usersData?.users.map(u => (
                    <tr key={u.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                      <td style={{ padding: '12px 16px', fontSize: 13 }}>{u.email}</td>
                      <td style={{ padding: '12px 16px', fontSize: 13, color: 'rgba(255,255,255,0.5)' }}>{u.name || '—'}</td>
                      <td style={{ padding: '12px 16px', fontSize: 12, color: 'rgba(255,255,255,0.3)' }}>
                        {new Date(u.createdAt).toLocaleDateString('uz')}
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        <select
                          value={u.role}
                          onChange={e => updateUser.mutate({ id: u.id, role: e.target.value })}
                          style={{ padding: '4px 8px', borderRadius: 8, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: '#e2e8f0', fontSize: 12 }}
                        >
                          <option value="user">User</option>
                          <option value="admin">Admin</option>
                        </select>
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        <select
                          value={u.tier}
                          onChange={e => updateUser.mutate({ id: u.id, tier: e.target.value })}
                          style={{ padding: '4px 8px', borderRadius: 8, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: '#e2e8f0', fontSize: 12 }}
                        >
                          <option value="free">Free</option>
                          <option value="pro">Pro</option>
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {usersData && (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 }}>
                <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13 }}>Jami: {usersData.total}</span>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={() => setUserPage(p => Math.max(1, p - 1))} disabled={userPage === 1} style={{ padding: '6px 14px', borderRadius: 8, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: '#e2e8f0', cursor: 'pointer' }}>←</button>
                  <span style={{ padding: '6px 14px', color: 'rgba(255,255,255,0.4)', fontSize: 13 }}>{userPage}</span>
                  <button onClick={() => setUserPage(p => p + 1)} disabled={userPage * 20 >= (usersData.total || 0)} style={{ padding: '6px 14px', borderRadius: 8, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: '#e2e8f0', cursor: 'pointer' }}>→</button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* AI Providers */}
        {tab === 'ai' && (
          <div className="animate-fadeIn" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div>
              <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 4 }}>AI Provayder Sozlamalari</h2>
              <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 14 }}>
                "chat" feature uchun aktiv sozlama AI javoblarida ishlatiladi
              </p>
            </div>
            {PROVIDERS.map(p => (
              <ProviderCard
                key={p.id}
                provider={p}
                configs={configs}
                onAdd={(config: any) => createConfig.mutate(config)}
                onDelete={(id: number) => deleteConfig.mutate(id)}
              />
            ))}
          </div>
        )}

        {/* Plans */}
        {tab === 'plans' && (
          <div className="animate-fadeIn">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
              {['free', 'pro'].map(tier => {
                const plan = plans?.find(p => p.tier === tier);
                const [name, setName] = useState(plan?.name || tier);
                const [price, setPrice] = useState(plan?.price || '0');
                return (
                  <div key={tier} className="glass-card" style={{ padding: 24 }}>
                    <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.4)', marginBottom: 16, textTransform: 'uppercase', letterSpacing: 1 }}>{tier}</div>
                    <div style={{ marginBottom: 12 }}>
                      <label style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', display: 'block', marginBottom: 6 }}>Nomi</label>
                      <input
                        value={name}
                        onChange={e => setName(e.target.value)}
                        disabled={tier === 'free'}
                        style={{
                          width: '100%', padding: '10px', borderRadius: 10,
                          background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)',
                          color: tier === 'free' ? 'rgba(255,255,255,0.3)' : '#e2e8f0', fontSize: 14, outline: 'none',
                        }}
                      />
                    </div>
                    <div style={{ marginBottom: 16 }}>
                      <label style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', display: 'block', marginBottom: 6 }}>Narxi ($)</label>
                      <input
                        value={price}
                        onChange={e => setPrice(e.target.value)}
                        disabled={tier === 'free'}
                        type="number"
                        style={{
                          width: '100%', padding: '10px', borderRadius: 10,
                          background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)',
                          color: tier === 'free' ? 'rgba(255,255,255,0.3)' : '#e2e8f0', fontSize: 14, outline: 'none',
                        }}
                      />
                    </div>
                    {tier !== 'free' && (
                      <button onClick={() => updatePlan.mutate({ tier, name, price })} className="btn-gradient" style={{ width: '100%', padding: '10px' }}>
                        Saqlash
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Logs */}
        {tab === 'logs' && (
          <div className="animate-fadeIn">
            <div className="glass-card" style={{ overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                    {['Vaqt', 'Tur', 'Email', 'Tavsif'].map(h => (
                      <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontSize: 12, color: 'rgba(255,255,255,0.4)', fontWeight: 600 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {logsData?.logs.map(l => (
                    <tr key={l.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                      <td style={{ padding: '10px 16px', fontSize: 12, color: 'rgba(255,255,255,0.3)', whiteSpace: 'nowrap' }}>
                        {new Date(l.createdAt).toLocaleString('uz')}
                      </td>
                      <td style={{ padding: '10px 16px' }}>
                        <span style={{
                          padding: '3px 8px', borderRadius: 6, fontSize: 11, fontWeight: 600,
                          background: 'rgba(99,102,241,0.2)', color: '#818cf8',
                        }}>{l.type}</span>
                      </td>
                      <td style={{ padding: '10px 16px', fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>{l.userEmail || '—'}</td>
                      <td style={{ padding: '10px 16px', fontSize: 13 }}>{l.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {logsData && (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 }}>
                <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13 }}>Jami: {logsData.total}</span>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={() => setLogPage(p => Math.max(1, p - 1))} disabled={logPage === 1} style={{ padding: '6px 14px', borderRadius: 8, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: '#e2e8f0', cursor: 'pointer' }}>←</button>
                  <span style={{ padding: '6px 14px', color: 'rgba(255,255,255,0.4)', fontSize: 13 }}>{logPage}</span>
                  <button onClick={() => setLogPage(p => p + 1)} disabled={logPage * 20 >= (logsData.total || 0)} style={{ padding: '6px 14px', borderRadius: 8, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: '#e2e8f0', cursor: 'pointer' }}>→</button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
