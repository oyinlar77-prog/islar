import { useState, useRef, useEffect } from 'react';
import { useClerk } from '@clerk/clerk-react';
import { useLocation } from 'wouter';
import {
  useMe, useConversations, useCreateConversation, useDeleteConversation,
  useMessages, useSendMessage, type Message,
} from '../hooks/api';

const TABS = [
  { id: 'chat', label: '💬 Chat' },
  { id: 'video', label: '🎬 Video' },
  { id: 'social', label: '📱 Ijtimoiy' },
  { id: 'money', label: '💰 Daromad' },
  { id: 'wallet', label: '💳 Hamyon' },
  { id: 'crypto', label: '📈 Kripto' },
  { id: 'modules', label: '📦 Modullar' },
  { id: 'log', label: '🧠 Log' },
];

const AGENTS = [
  { id: 'chat', label: 'Umumiy' },
  { id: 'code', label: 'Kod' },
  { id: 'bank', label: 'Bank' },
  { id: 'gov', label: 'Davlat' },
  { id: 'doctor', label: 'Tibbiy' },
  { id: 'lawyer', label: 'Huquq' },
  { id: 'translate', label: 'Tarjima' },
  { id: 'social', label: 'SMM' },
  { id: 'money', label: 'Pul' },
  { id: 'edu', label: "Ta'lim" },
];

const CRYPTO_DATA = [
  { symbol: 'BTC', name: 'Bitcoin', price: 67420, change: 2.3 },
  { symbol: 'ETH', name: 'Ethereum', price: 3840, change: 1.8 },
  { symbol: 'BNB', name: 'BNB', price: 580, change: -0.5 },
  { symbol: 'SOL', name: 'Solana', price: 185, change: 4.2 },
  { symbol: 'USDT', name: 'Tether', price: 1.0, change: 0.01 },
  { symbol: 'ADA', name: 'Cardano', price: 0.58, change: -1.2 },
  { symbol: 'DOGE', name: 'Dogecoin', price: 0.18, change: 6.7 },
  { symbol: 'UZS', name: "O'zbek so'mi", price: 0.000079, change: -0.1 },
];

function AvatarSVG() {
  return (
    <svg width="120" height="120" viewBox="0 0 120 120" className="animate-glowPulse" style={{ margin: '20px auto', display: 'block' }}>
      <circle cx="60" cy="60" r="50" fill="rgba(99,102,241,0.1)" stroke="rgba(99,102,241,0.4)" strokeWidth="1"/>
      <g className="animate-spin-slow" style={{ transformOrigin: '60px 60px' }}>
        <circle cx="60" cy="10" r="4" fill="#6366f1"/>
        <circle cx="110" cy="60" r="4" fill="#818cf8" opacity="0.7"/>
        <circle cx="60" cy="110" r="4" fill="#6366f1" opacity="0.5"/>
        <circle cx="10" cy="60" r="4" fill="#818cf8" opacity="0.3"/>
      </g>
      <circle cx="60" cy="60" r="30" fill="rgba(99,102,241,0.2)" stroke="rgba(99,102,241,0.6)" strokeWidth="2"/>
      <text x="60" y="68" textAnchor="middle" fontSize="24" fill="white">🧠</text>
    </svg>
  );
}

function CryptoTab() {
  const [prices, setPrices] = useState(CRYPTO_DATA);

  useEffect(() => {
    const interval = setInterval(() => {
      setPrices(prev => prev.map(c => ({
        ...c,
        price: c.price * (1 + (Math.random() - 0.5) * 0.002),
        change: c.change + (Math.random() - 0.5) * 0.1,
      })));
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{ padding: 16 }}>
      <div style={{ marginBottom: 16, display: 'flex', gap: 12 }}>
        <div className="glass-card" style={{ flex: 1, padding: 16, textAlign: 'center' }}>
          <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, marginBottom: 4 }}>Portfolio</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: '#34d399' }}>$12,847</div>
          <div style={{ fontSize: 12, color: '#34d399' }}>↑ +$347 (+2.8%)</div>
        </div>
        <div className="glass-card" style={{ flex: 1, padding: 16, textAlign: 'center' }}>
          <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, marginBottom: 4 }}>Foyda</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: '#34d399' }}>+$2,341</div>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>Bu oy</div>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {prices.map(c => (
          <div key={c.symbol} className="glass-card" style={{
            padding: '12px 16px', display: 'flex', alignItems: 'center',
            justifyContent: 'space-between',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{
                width: 36, height: 36, borderRadius: 10,
                background: 'rgba(99,102,241,0.2)', display: 'flex',
                alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: '#818cf8',
              }}>{c.symbol.slice(0, 2)}</div>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{c.symbol}</div>
                <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>{c.name}</div>
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontWeight: 600, fontSize: 14 }}>
                ${c.price < 0.01 ? c.price.toFixed(6) : c.price < 1 ? c.price.toFixed(4) : c.price.toFixed(2)}
              </div>
              <div style={{ fontSize: 12, color: c.change >= 0 ? '#34d399' : '#f87171' }}>
                {c.change >= 0 ? '↑' : '↓'} {Math.abs(c.change).toFixed(2)}%
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <button style={{
                padding: '4px 10px', borderRadius: 8, fontSize: 11, fontWeight: 600,
                background: 'rgba(52,211,153,0.15)', color: '#34d399', border: '1px solid rgba(52,211,153,0.3)', cursor: 'pointer',
              }}>Sotib ol</button>
              <button style={{
                padding: '4px 10px', borderRadius: 8, fontSize: 11, fontWeight: 600,
                background: 'rgba(248,113,113,0.15)', color: '#f87171', border: '1px solid rgba(248,113,113,0.3)', cursor: 'pointer',
              }}>Sot</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function WalletTab() {
  const [copied, setCopied] = useState(false);
  const address = '0x742d35Cc6634C0532925a3b8D4b1337E9c3';

  const copy = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div style={{ padding: 16 }}>
      {/* Balance card */}
      <div style={{
        borderRadius: 20, padding: 28, marginBottom: 16,
        background: 'linear-gradient(135deg, rgba(99,102,241,0.3), rgba(129,140,248,0.2))',
        border: '1px solid rgba(99,102,241,0.3)', backdropFilter: 'blur(20px)',
      }}>
        <div style={{ color: 'rgba(255,255,255,0.6)', fontSize: 13, marginBottom: 8 }}>Jami balans</div>
        <div style={{ fontSize: 36, fontWeight: 800, color: 'white', marginBottom: 4 }}>$2,847.50</div>
        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)' }}>≈ 35,593,750 UZS</div>
      </div>

      {/* Wallet address */}
      <div className="glass-card" style={{ padding: 16, marginBottom: 16 }}>
        <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, marginBottom: 8 }}>Hamyon manzili</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ flex: 1, fontFamily: 'monospace', fontSize: 12, color: '#818cf8', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {address}
          </div>
          <button onClick={copy} style={{
            padding: '6px 12px', borderRadius: 8, fontSize: 12,
            background: copied ? 'rgba(52,211,153,0.2)' : 'rgba(99,102,241,0.2)',
            color: copied ? '#34d399' : '#818cf8',
            border: `1px solid ${copied ? 'rgba(52,211,153,0.3)' : 'rgba(99,102,241,0.3)'}`,
            cursor: 'pointer',
          }}>
            {copied ? '✓ Nusxalandi' : 'Nusxa'}
          </button>
        </div>
      </div>

      {/* Actions */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
        <button className="btn-gradient" style={{ padding: '16px', borderRadius: 16, fontSize: 15 }}>
          ↗ Yuborish
        </button>
        <button style={{
          padding: '16px', borderRadius: 16, fontSize: 15, fontWeight: 600,
          background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)',
          color: '#e2e8f0', cursor: 'pointer',
        }}>
          ↙ Qabul qilish
        </button>
      </div>

      {/* Transactions */}
      <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13, marginBottom: 12 }}>So'nggi amallar</div>
      {[
        { type: 'kirdi', amount: '+$500', from: '0x123...abc', time: '2 soat oldin', color: '#34d399' },
        { type: 'chiqdi', amount: '-$120', from: '0x456...def', time: 'Kecha', color: '#f87171' },
        { type: 'kirdi', amount: '+$1,200', from: '0x789...ghi', time: '3 kun oldin', color: '#34d399' },
      ].map((tx, i) => (
        <div key={i} className="glass-card" style={{
          padding: '12px 16px', marginBottom: 8, display: 'flex',
          alignItems: 'center', justifyContent: 'space-between',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 32, height: 32, borderRadius: 8,
              background: `${tx.type === 'kirdi' ? 'rgba(52,211,153' : 'rgba(248,113,113'},.15)`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>{tx.type === 'kirdi' ? '↙' : '↗'}</div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>{tx.from}</div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)' }}>{tx.time}</div>
            </div>
          </div>
          <div style={{ fontWeight: 700, color: tx.color }}>{tx.amount}</div>
        </div>
      ))}
    </div>
  );
}

export default function ChatPage() {
  const { data: user } = useMe();
  const { data: conversations = [] } = useConversations();
  const createConv = useCreateConversation();
  const deleteConv = useDeleteConversation();
  const sendMsg = useSendMessage();
  const { signOut } = useClerk();
  const [, navigate] = useLocation();

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('chat');
  const [selectedConvId, setSelectedConvId] = useState<number | null>(null);
  const [selectedAgent, setSelectedAgent] = useState('chat');
  const [inputText, setInputText] = useState('');
  const [localMessages, setLocalMessages] = useState<Message[]>([]);
  const [isSending, setIsSending] = useState(false);
  const { data: messages = [] } = useMessages(selectedConvId);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const [isListening, setIsListening] = useState(false);

  useEffect(() => {
    setLocalMessages(messages);
  }, [messages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [localMessages]);

  const handleNewChat = async () => {
    const conv = await createConv.mutateAsync('New Conversation');
    setSelectedConvId(conv.id);
    setLocalMessages([]);
    setDrawerOpen(false);
  };

  const handleSend = async () => {
    if (!inputText.trim() || isSending) return;

    let convId = selectedConvId;
    if (!convId) {
      const conv = await createConv.mutateAsync(inputText.slice(0, 50));
      convId = conv.id;
      setSelectedConvId(convId);
    }

    const userMessage: Message = {
      id: Date.now(),
      conversationId: convId,
      role: 'user',
      content: inputText,
      createdAt: new Date().toISOString(),
    };

    setLocalMessages(prev => [...prev, userMessage]);
    const sentText = inputText;
    setInputText('');
    setIsSending(true);

    try {
      const reply = await sendMsg.mutateAsync({ conversationId: convId, content: sentText, agentId: selectedAgent });
      setLocalMessages(prev => [...prev.filter(m => m.id !== userMessage.id), userMessage, reply]);
    } catch {
      setLocalMessages(prev => [...prev, {
        id: Date.now() + 1, conversationId: convId!, role: 'assistant',
        content: "Xatolik yuz berdi. Iltimos, admin panelda AI provayderni sozlang.",
        createdAt: new Date().toISOString(),
      }]);
    } finally {
      setIsSending(false);
    }
  };

  const handleVoice = () => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) return;
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    recognitionRef.current = new SpeechRec();
    recognitionRef.current.lang = 'uz-UZ';
    recognitionRef.current.onresult = (e: any) => {
      setInputText(e.results[0][0].transcript);
    };
    recognitionRef.current.onend = () => setIsListening(false);
    recognitionRef.current.start();
    setIsListening(true);
  };

  const handleTTS = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'uz-UZ';
    speechSynthesis.speak(utterance);
  };

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: '#080d1a', overflow: 'hidden' }}>
      {/* Drawer overlay */}
      {drawerOpen && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', zIndex: 99, backdropFilter: 'blur(4px)' }}
          onClick={() => setDrawerOpen(false)}
        />
      )}

      {/* Drawer */}
      <div style={{
        position: 'fixed', left: 0, top: 0, bottom: 0, width: 280, zIndex: 100,
        background: '#0d1526', borderRight: '1px solid rgba(255,255,255,0.08)',
        transform: drawerOpen ? 'translateX(0)' : 'translateX(-100%)',
        transition: 'transform 0.3s ease', display: 'flex', flexDirection: 'column',
      }}>
        {/* User info */}
        <div style={{ padding: 20, borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              width: 44, height: 44, borderRadius: 12, background: 'linear-gradient(135deg, #6366f1, #818cf8)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18,
            }}>
              {user?.name?.[0] || user?.email?.[0] || '?'}
            </div>
            <div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>{user?.name || 'Foydalanuvchi'}</div>
              <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                <span style={{
                  padding: '2px 8px', borderRadius: 6, fontSize: 11, fontWeight: 600,
                  background: user?.role === 'admin' ? 'rgba(248,113,113,0.2)' : 'rgba(99,102,241,0.2)',
                  color: user?.role === 'admin' ? '#f87171' : '#818cf8',
                }}>
                  {user?.role === 'admin' ? 'Admin' : 'Foydalanuvchi'}
                </span>
                <span style={{
                  padding: '2px 8px', borderRadius: 6, fontSize: 11, fontWeight: 600,
                  background: user?.tier === 'pro' ? 'rgba(52,211,153,0.2)' : 'rgba(255,255,255,0.08)',
                  color: user?.tier === 'pro' ? '#34d399' : 'rgba(255,255,255,0.4)',
                }}>
                  {user?.tier === 'pro' ? 'Pro' : 'Free'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* New Chat */}
        <div style={{ padding: '12px 16px' }}>
          <button onClick={handleNewChat} className="btn-gradient" style={{ width: '100%', padding: '12px', fontSize: 14 }}>
            + Yangi Chat
          </button>
        </div>

        {/* Conversations */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '0 8px' }}>
          {conversations.map(c => (
            <div
              key={c.id}
              onClick={() => { setSelectedConvId(c.id); setDrawerOpen(false); }}
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '10px 12px', borderRadius: 10, cursor: 'pointer', marginBottom: 2,
                background: selectedConvId === c.id ? 'rgba(99,102,241,0.15)' : 'transparent',
                transition: 'background 0.15s',
              }}
              onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.05)'}
              onMouseLeave={e => e.currentTarget.style.background = selectedConvId === c.id ? 'rgba(99,102,241,0.15)' : 'transparent'}
            >
              <div style={{ flex: 1, overflow: 'hidden' }}>
                <div style={{ fontSize: 13, fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {c.title}
                </div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', marginTop: 2 }}>
                  {new Date(c.updatedAt).toLocaleDateString('uz')}
                </div>
              </div>
              <button
                onClick={e => { e.stopPropagation(); deleteConv.mutate(c.id); if (selectedConvId === c.id) setSelectedConvId(null); }}
                style={{ padding: '4px 6px', borderRadius: 6, background: 'transparent', border: 'none', color: '#f87171', cursor: 'pointer', fontSize: 14, opacity: 0.6 }}
              >🗑</button>
            </div>
          ))}
        </div>

        {/* Bottom nav */}
        <div style={{ padding: '12px 8px', borderTop: '1px solid rgba(255,255,255,0.08)', display: 'flex', flexDirection: 'column', gap: 4 }}>
          {user?.role === 'admin' && (
            <>
              <button onClick={() => navigate('/admin')} style={{
                width: '100%', padding: '10px 16px', borderRadius: 10, border: 'none',
                background: 'rgba(248,113,113,0.1)', color: '#f87171', cursor: 'pointer',
                fontSize: 13, fontWeight: 500, textAlign: 'left', display: 'flex', alignItems: 'center', gap: 8,
              }}>🔴 Admin Panel</button>
              <button onClick={() => { setActiveTab('log'); setDrawerOpen(false); }} style={{
                width: '100%', padding: '10px 16px', borderRadius: 10, border: 'none',
                background: 'rgba(99,102,241,0.1)', color: '#818cf8', cursor: 'pointer',
                fontSize: 13, fontWeight: 500, textAlign: 'left', display: 'flex', alignItems: 'center', gap: 8,
              }}>📋 Loglar & Statistika</button>
            </>
          )}
          <button onClick={() => navigate('/settings')} style={{
            width: '100%', padding: '10px 16px', borderRadius: 10, border: 'none',
            background: 'transparent', color: 'rgba(255,255,255,0.5)', cursor: 'pointer',
            fontSize: 13, textAlign: 'left',
          }}>⚙️ Sozlamalar</button>
          <button onClick={() => signOut()} style={{
            width: '100%', padding: '10px 16px', borderRadius: 10, border: 'none',
            background: 'rgba(248,113,113,0.1)', color: '#f87171', cursor: 'pointer',
            fontSize: 13, textAlign: 'left',
          }}>Chiqish</button>
        </div>
      </div>

      {/* Top header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '12px 16px', borderBottom: '1px solid rgba(255,255,255,0.06)',
        background: 'rgba(8,13,26,0.95)', backdropFilter: 'blur(20px)', flexShrink: 0,
      }}>
        <button onClick={() => setDrawerOpen(true)} style={{
          padding: '8px 10px', borderRadius: 10, border: 'none',
          background: 'rgba(255,255,255,0.06)', color: '#e2e8f0', cursor: 'pointer', fontSize: 18,
        }}>☰</button>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: 'linear-gradient(135deg, #6366f1, #818cf8)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14 }}>🧠</div>
          <span style={{ fontWeight: 700, fontSize: 16 }}>Ulugbek AI</span>
        </div>
        <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', background: 'rgba(255,255,255,0.06)', padding: '4px 10px', borderRadius: 8 }}>
          {localMessages.length} xabar
        </div>
      </div>

      {/* Tab bar */}
      <div style={{ padding: '8px 12px', borderBottom: '1px solid rgba(255,255,255,0.06)', flexShrink: 0, background: '#080d1a' }}>
        <div className="tab-bar">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)} className={`tab-item ${activeTab === t.id ? 'active' : ''}`}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {activeTab === 'chat' && (
          <>
            {/* Chat messages */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '16px' }}>
              {localMessages.length === 0 ? (
                <div className="animate-fadeIn">
                  <AvatarSVG />
                  <div style={{ textAlign: 'center', marginBottom: 20 }}>
                    <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 8 }}>Salom! 👋</h2>
                    <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 14 }}>
                      Qanday yordam bera olaman?
                    </p>
                  </div>

                  {/* Agent selector */}
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'center', marginBottom: 20 }}>
                    {AGENTS.map(a => (
                      <button key={a.id} onClick={() => setSelectedAgent(a.id)} style={{
                        padding: '8px 16px', borderRadius: 20, fontSize: 13, fontWeight: 500,
                        border: selectedAgent === a.id ? '1px solid #6366f1' : '1px solid rgba(255,255,255,0.1)',
                        background: selectedAgent === a.id ? 'rgba(99,102,241,0.2)' : 'rgba(255,255,255,0.04)',
                        color: selectedAgent === a.id ? '#818cf8' : 'rgba(255,255,255,0.5)',
                        cursor: 'pointer', transition: 'all 0.2s',
                      }}>
                        {a.label}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {/* Agent selector when messages exist */}
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 8 }}>
                    {AGENTS.map(a => (
                      <button key={a.id} onClick={() => setSelectedAgent(a.id)} style={{
                        padding: '5px 12px', borderRadius: 16, fontSize: 12,
                        border: selectedAgent === a.id ? '1px solid #6366f1' : '1px solid rgba(255,255,255,0.08)',
                        background: selectedAgent === a.id ? 'rgba(99,102,241,0.2)' : 'transparent',
                        color: selectedAgent === a.id ? '#818cf8' : 'rgba(255,255,255,0.4)',
                        cursor: 'pointer',
                      }}>{a.label}</button>
                    ))}
                  </div>

                  {localMessages.map(m => (
                    <div key={m.id} style={{ display: 'flex', flexDirection: 'column', alignItems: m.role === 'user' ? 'flex-end' : 'flex-start' }}>
                      <div className={m.role === 'user' ? 'msg-user' : 'msg-assistant'} style={{ fontSize: 14, lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
                        {m.content}
                      </div>
                      {m.role === 'assistant' && (
                        <button onClick={() => handleTTS(m.content)} style={{
                          marginTop: 4, padding: '3px 8px', borderRadius: 6, fontSize: 11,
                          background: 'transparent', border: '1px solid rgba(255,255,255,0.1)',
                          color: 'rgba(255,255,255,0.4)', cursor: 'pointer',
                        }}>🔊 Tinglash</button>
                      )}
                    </div>
                  ))}
                  {isSending && (
                    <div className="msg-assistant" style={{ fontSize: 14 }}>
                      <span style={{ opacity: 0.6 }}>⏳ Javob yozilmoqda...</span>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </div>

            {/* Input bar */}
            <div style={{
              padding: '12px 16px', borderTop: '1px solid rgba(255,255,255,0.06)',
              background: '#080d1a', flexShrink: 0,
            }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
                <button style={{
                  padding: '10px', borderRadius: 12, border: '1px solid rgba(255,255,255,0.1)',
                  background: 'rgba(255,255,255,0.04)', color: 'rgba(255,255,255,0.5)', cursor: 'pointer', fontSize: 16,
                }}>📎</button>
                <button onClick={handleVoice} style={{
                  padding: '10px', borderRadius: 12, border: `1px solid ${isListening ? 'rgba(248,113,113,0.4)' : 'rgba(255,255,255,0.1)'}`,
                  background: isListening ? 'rgba(248,113,113,0.15)' : 'rgba(255,255,255,0.04)',
                  color: isListening ? '#f87171' : 'rgba(255,255,255,0.5)', cursor: 'pointer', fontSize: 16,
                }}>🎤</button>
                <textarea
                  value={inputText}
                  onChange={e => setInputText(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                  placeholder="Xabar yozing..."
                  rows={1}
                  className="chat-input"
                  style={{ flex: 1, fontSize: 14, minHeight: 44, maxHeight: 120 }}
                />
                <button
                  onClick={handleSend}
                  disabled={isSending || !inputText.trim()}
                  className="btn-gradient"
                  style={{ padding: '10px 20px', opacity: isSending || !inputText.trim() ? 0.5 : 1 }}
                >
                  ➤
                </button>
              </div>
            </div>
          </>
        )}

        {activeTab === 'crypto' && (
          <div style={{ flex: 1, overflowY: 'auto' }}>
            <CryptoTab />
          </div>
        )}

        {activeTab === 'wallet' && (
          <div style={{ flex: 1, overflowY: 'auto' }}>
            <WalletTab />
          </div>
        )}

        {(activeTab === 'video' || activeTab === 'social' || activeTab === 'money' || activeTab === 'modules' || activeTab === 'log') && (
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 16 }}>
            <div style={{ fontSize: 48 }}>🚧</div>
            <div style={{ fontSize: 18, fontWeight: 600 }}>Tez orada</div>
            <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 14 }}>Bu bo'lim ishlanmoqda</div>
          </div>
        )}
      </div>
    </div>
  );
}
