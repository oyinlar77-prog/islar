import { useClerk } from '@clerk/clerk-react';

const FEATURES = [
  { icon: '🤖', title: 'Aqlli Suhbat', desc: "O'zbek tilida tushunadi va javob beradi" },
  { icon: '💻', title: 'Kod Yozish', desc: 'Professional darajada kod generatsiya qiladi' },
  { icon: '⚖️', title: 'Huquqiy Maslahat', desc: "O'zbekiston qonunlari bo'yicha yordam" },
  { icon: '🏥', title: 'Tibbiy Ma\'lumot', desc: 'Sog\'liq bo\'yicha ishonchli ma\'lumotlar' },
  { icon: '🌐', title: 'Tarjima', desc: "Ko'p tilli tarjima xizmati" },
  { icon: '📱', title: 'SMM Kontent', desc: 'Ijtimoiy tarmoqlar uchun kontent yaratish' },
];

export default function LandingPage() {
  const { openSignIn } = useClerk();

  return (
    <div style={{ minHeight: '100vh', background: '#080d1a' }}>
      {/* Header */}
      <header style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '20px 40px', borderBottom: '1px solid rgba(255,255,255,0.06)',
        position: 'sticky', top: 0, zIndex: 100,
        background: 'rgba(8,13,26,0.95)', backdropFilter: 'blur(20px)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 40, height: 40, borderRadius: 12,
            background: 'linear-gradient(135deg, #6366f1, #818cf8)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 20,
          }}>🧠</div>
          <span style={{ fontSize: 20, fontWeight: 700, color: '#e2e8f0' }}>Ulugbek AI</span>
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          <button
            onClick={() => openSignIn()}
            style={{
              padding: '10px 24px', borderRadius: 12, border: '1px solid rgba(255,255,255,0.15)',
              background: 'transparent', color: '#e2e8f0', cursor: 'pointer', fontSize: 14, fontWeight: 500,
            }}
          >
            Kirish
          </button>
          <button
            onClick={() => openSignIn()}
            className="btn-gradient"
            style={{ padding: '10px 24px', fontSize: 14 }}
          >
            Boshlash →
          </button>
        </div>
      </header>

      {/* Hero */}
      <section style={{ textAlign: 'center', padding: '100px 40px 80px', maxWidth: 800, margin: '0 auto' }}>
        <div style={{
          display: 'inline-block', padding: '6px 16px', borderRadius: 20,
          background: 'rgba(99,102,241,0.15)', border: '1px solid rgba(99,102,241,0.3)',
          color: '#818cf8', fontSize: 13, fontWeight: 500, marginBottom: 24,
        }}>
          ✨ O'zbek tilidagi birinchi AI platforma
        </div>
        <h1 style={{
          fontSize: 56, fontWeight: 800, lineHeight: 1.15, marginBottom: 24,
          background: 'linear-gradient(135deg, #e2e8f0 30%, #6366f1, #818cf8)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
        }}>
          Ishingizni kuchlaydigan intellekt
        </h1>
        <p style={{ fontSize: 20, color: 'rgba(255,255,255,0.5)', marginBottom: 40, lineHeight: 1.6 }}>
          Ulugbek AI — sizning aqlli yordamchingiz. Suhbat, kod, tarjima,
          huquqiy va tibbiy maslahat — barchasi bir joyda, o'zbek tilida.
        </p>
        <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap' }}>
          <button
            onClick={() => openSignIn()}
            className="btn-gradient"
            style={{ padding: '16px 40px', fontSize: 16 }}
          >
            Bepul Boshlash
          </button>
          <button
            style={{
              padding: '16px 40px', borderRadius: 12, border: '1px solid rgba(255,255,255,0.15)',
              background: 'transparent', color: '#e2e8f0', cursor: 'pointer', fontSize: 16,
            }}
          >
            Videoni Ko'rish ▶
          </button>
        </div>

        {/* Stats */}
        <div style={{ display: 'flex', gap: 40, justifyContent: 'center', marginTop: 60, flexWrap: 'wrap' }}>
          {[['10K+', 'Foydalanuvchilar'], ['1M+', 'Javoblar'], ['99%', 'Qoniqish']].map(([num, label]) => (
            <div key={label} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 32, fontWeight: 800, color: '#6366f1' }}>{num}</div>
              <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.4)' }}>{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section style={{ padding: '80px 40px', maxWidth: 1100, margin: '0 auto' }}>
        <h2 style={{ textAlign: 'center', fontSize: 36, fontWeight: 700, marginBottom: 16, color: '#e2e8f0' }}>
          Imkoniyatlar
        </h2>
        <p style={{ textAlign: 'center', color: 'rgba(255,255,255,0.4)', marginBottom: 60 }}>
          Keng qamrovli AI xizmatlar
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 20 }}>
          {FEATURES.map((f) => (
            <div key={f.title} className="glass-card" style={{ padding: 28, transition: 'all 0.2s', cursor: 'default' }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = 'rgba(99,102,241,0.3)')}
              onMouseLeave={e => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)')}
            >
              <div style={{ fontSize: 36, marginBottom: 16 }}>{f.icon}</div>
              <h3 style={{ fontSize: 18, fontWeight: 600, color: '#e2e8f0', marginBottom: 8 }}>{f.title}</h3>
              <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 14, lineHeight: 1.6 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section style={{ padding: '80px 40px', maxWidth: 800, margin: '0 auto' }}>
        <h2 style={{ textAlign: 'center', fontSize: 36, fontWeight: 700, marginBottom: 16, color: '#e2e8f0' }}>
          Narxlar
        </h2>
        <p style={{ textAlign: 'center', color: 'rgba(255,255,255,0.4)', marginBottom: 60 }}>
          Siz uchun qulay tarif
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          {/* Free */}
          <div className="glass-card" style={{ padding: 32 }}>
            <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.4)', marginBottom: 8 }}>BEPUL</div>
            <div style={{ fontSize: 40, fontWeight: 800, color: '#e2e8f0', marginBottom: 24 }}>$0</div>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 12 }}>
              {['Cheksiz suhbat', '1 ta rasm tahlili', '1 ta video tahlil', '1 ta fayl yuklash'].map(f => (
                <li key={f} style={{ color: 'rgba(255,255,255,0.6)', fontSize: 14, display: 'flex', gap: 8 }}>
                  <span style={{ color: '#34d399' }}>✓</span> {f}
                </li>
              ))}
            </ul>
            <button onClick={() => openSignIn()} style={{
              marginTop: 32, width: '100%', padding: '12px', borderRadius: 12,
              border: '1px solid rgba(255,255,255,0.15)', background: 'transparent',
              color: '#e2e8f0', cursor: 'pointer', fontWeight: 600,
            }}>Boshlash</button>
          </div>
          {/* Pro */}
          <div style={{
            padding: 32, borderRadius: 16, border: '1px solid rgba(99,102,241,0.4)',
            background: 'rgba(99,102,241,0.08)', position: 'relative',
          }}>
            <div style={{
              position: 'absolute', top: -12, right: 24, padding: '4px 12px',
              background: 'linear-gradient(135deg, #6366f1, #818cf8)', borderRadius: 20,
              fontSize: 12, fontWeight: 600, color: 'white',
            }}>TAVSIYA</div>
            <div style={{ fontSize: 14, color: '#818cf8', marginBottom: 8 }}>PRO</div>
            <div style={{ fontSize: 40, fontWeight: 800, color: '#e2e8f0', marginBottom: 24 }}>$9.99</div>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 12 }}>
              {['Cheksiz hamma narsa', 'Barcha AI agentlar', 'Ustunlik qo\'llab-quvvatlash', 'API kirish', 'Maxsus modellar'].map(f => (
                <li key={f} style={{ color: 'rgba(255,255,255,0.6)', fontSize: 14, display: 'flex', gap: 8 }}>
                  <span style={{ color: '#34d399' }}>✓</span> {f}
                </li>
              ))}
            </ul>
            <button onClick={() => openSignIn()} className="btn-gradient" style={{ marginTop: 32, width: '100%', padding: '12px' }}>
              Pro olish
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={{
        borderTop: '1px solid rgba(255,255,255,0.06)', padding: '40px',
        textAlign: 'center', color: 'rgba(255,255,255,0.3)', fontSize: 14,
      }}>
        © 2025 Ulugbek AI. Barcha huquqlar himoyalangan.
      </footer>
    </div>
  );
}
