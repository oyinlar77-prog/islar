import { useClerk } from '@clerk/clerk-react';
import { useLocation } from 'wouter';
import { useMe, useUsage } from '../hooks/api';

export default function SettingsPage() {
  const { data: user } = useMe();
  const { data: usage } = useUsage();
  const { signOut } = useClerk();
  const [, navigate] = useLocation();

  return (
    <div style={{ height: '100vh', overflowY: 'auto', background: '#080d1a', color: '#e2e8f0' }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 16, padding: '16px 24px',
        borderBottom: '1px solid rgba(255,255,255,0.06)', position: 'sticky', top: 0,
        background: 'rgba(8,13,26,0.95)', backdropFilter: 'blur(20px)', zIndex: 10,
      }}>
        <button onClick={() => navigate('/chat')} style={{
          padding: '8px 12px', borderRadius: 10, border: 'none',
          background: 'rgba(255,255,255,0.06)', color: '#e2e8f0', cursor: 'pointer',
        }}>← Orqaga</button>
        <h1 style={{ fontSize: 18, fontWeight: 700 }}>⚙️ Sozlamalar</h1>
      </div>

      <div style={{ maxWidth: 600, margin: '32px auto', padding: '0 20px' }}>
        {/* Profile */}
        <div className="glass-card" style={{ padding: 24, marginBottom: 20 }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 20 }}>Profil Ma'lumotlari</h2>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
            <div style={{
              width: 60, height: 60, borderRadius: 16, background: 'linear-gradient(135deg, #6366f1, #818cf8)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24,
            }}>
              {user?.name?.[0] || user?.email?.[0] || '?'}
            </div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 16 }}>{user?.name || 'Foydalanuvchi'}</div>
              <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 14 }}>{user?.email}</div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <span style={{
              padding: '6px 14px', borderRadius: 10, fontSize: 13, fontWeight: 600,
              background: user?.role === 'admin' ? 'rgba(248,113,113,0.15)' : 'rgba(99,102,241,0.15)',
              color: user?.role === 'admin' ? '#f87171' : '#818cf8',
            }}>
              {user?.role === 'admin' ? '🔴 Admin' : '👤 Foydalanuvchi'}
            </span>
            <span style={{
              padding: '6px 14px', borderRadius: 10, fontSize: 13, fontWeight: 600,
              background: user?.tier === 'pro' ? 'rgba(52,211,153,0.15)' : 'rgba(255,255,255,0.06)',
              color: user?.tier === 'pro' ? '#34d399' : 'rgba(255,255,255,0.4)',
            }}>
              {user?.tier === 'pro' ? '💎 Pro' : '🆓 Free'}
            </span>
          </div>
        </div>

        {/* Subscription */}
        <div className="glass-card" style={{ padding: 24, marginBottom: 20 }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Obuna Holati</h2>
          {user?.tier === 'free' ? (
            <>
              <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 14, marginBottom: 16 }}>
                Hozir siz bepul tarifda foydalanmoqdasiz. Pro tarifga o'ting va barcha imkoniyatlardan foydalaning.
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 20 }}>
                {['Cheksiz barcha xususiyatlar', 'Barcha AI agentlar', 'Ustunlik qo\'llab-quvvatlash', 'API kirish'].map(f => (
                  <div key={f} style={{ display: 'flex', gap: 8, color: 'rgba(255,255,255,0.6)', fontSize: 14 }}>
                    <span style={{ color: '#34d399' }}>✓</span> {f}
                  </div>
                ))}
              </div>
              <button className="btn-gradient" style={{ width: '100%', padding: '14px', fontSize: 15 }}>
                Pro ga O'tish — $9.99/oy
              </button>
            </>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ fontSize: 36 }}>💎</div>
              <div>
                <div style={{ fontWeight: 700, color: '#34d399', fontSize: 16 }}>Pro Tarifda</div>
                <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 14 }}>Barcha imkoniyatlar ochiq</div>
              </div>
            </div>
          )}
        </div>

        {/* Usage */}
        <div className="glass-card" style={{ padding: 24, marginBottom: 20 }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Foydalanish Statistikasi</h2>
          {usage && usage.length > 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {usage.map(u => (
                <div key={u.feature} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                  <span style={{ fontSize: 14, color: 'rgba(255,255,255,0.6)' }}>{u.feature}</span>
                  <span style={{ fontWeight: 600, fontSize: 14, color: '#818cf8' }}>{u.count} marta</span>
                </div>
              ))}
            </div>
          ) : (
            <p style={{ color: 'rgba(255,255,255,0.3)', fontSize: 14 }}>Hali foydalanish yo'q</p>
          )}
        </div>

        {/* Danger zone */}
        <div className="glass-card" style={{ padding: 24, border: '1px solid rgba(248,113,113,0.2)' }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16, color: '#f87171' }}>Xavfli Zona</h2>
          <button
            onClick={() => signOut()}
            style={{
              width: '100%', padding: '12px', borderRadius: 12, fontSize: 14, fontWeight: 600,
              background: 'rgba(248,113,113,0.15)', border: '1px solid rgba(248,113,113,0.3)',
              color: '#f87171', cursor: 'pointer',
            }}
          >
            Hisobdan Chiqish
          </button>
        </div>
      </div>
    </div>
  );
}
