import axios from 'axios';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

const api = axios.create({
  baseURL: '/api',
  withCredentials: true,
});

// Types
export interface User {
  id: number;
  clerkId: string;
  email: string;
  name?: string | null;
  role: 'user' | 'admin';
  tier: 'free' | 'pro';
  createdAt: string;
}

export interface Conversation {
  id: number;
  userId: number;
  title: string;
  createdAt: string;
  updatedAt: string;
}

export interface Message {
  id: number;
  conversationId: number;
  role: 'user' | 'assistant';
  content: string;
  createdAt: string;
}

export interface Plan {
  id: number;
  tier: string;
  name: string;
  price: string;
  features?: string[] | null;
}

export interface ApiConfig {
  id: number;
  feature: string;
  provider: 'groq' | 'openai' | 'anthropic' | 'gemini';
  model: string;
  apiKey?: string | null;
  isActive: boolean;
}

export interface AdminStats {
  totalUsers: number;
  proUsers: number;
  freeUsers: number;
  totalConversations: number;
  totalMessages: number;
}

export interface ActivityLog {
  id: number;
  userId?: number | null;
  userEmail?: string | null;
  type: string;
  description: string;
  createdAt: string;
}

export interface UsageStat {
  feature: string;
  count: number;
  resetAt?: string | null;
}

// Hooks
export function useMe() {
  return useQuery<User>({
    queryKey: ['me'],
    queryFn: async () => {
      const { data } = await api.get('/me');
      return data;
    },
    retry: false,
  });
}

export function useConversations() {
  return useQuery<Conversation[]>({
    queryKey: ['conversations'],
    queryFn: async () => {
      const { data } = await api.get('/conversations');
      return data;
    },
  });
}

export function useCreateConversation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (title?: string) => {
      const { data } = await api.post('/conversations', { title });
      return data as Conversation;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['conversations'] }),
  });
}

export function useDeleteConversation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      await api.delete(`/conversations/${id}`);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['conversations'] }),
  });
}

export function useMessages(conversationId: number | null) {
  return useQuery<Message[]>({
    queryKey: ['messages', conversationId],
    queryFn: async () => {
      const { data } = await api.get(`/conversations/${conversationId}/messages`);
      return data;
    },
    enabled: !!conversationId,
  });
}

export function useSendMessage() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ conversationId, content, agentId }: { conversationId: number; content: string; agentId?: string }) => {
      const { data } = await api.post(`/conversations/${conversationId}/messages`, { content, agentId });
      return data as Message;
    },
    onSuccess: (_, { conversationId }) => {
      qc.invalidateQueries({ queryKey: ['messages', conversationId] });
    },
  });
}

export function useAiComplete() {
  return useMutation({
    mutationFn: async ({ messages, agentId }: { messages: { role: string; content: string }[]; agentId?: string }) => {
      const { data } = await api.post('/ai/complete', { messages, agentId });
      return data as { content: string };
    },
  });
}

export function usePlans() {
  return useQuery<Plan[]>({
    queryKey: ['plans'],
    queryFn: async () => {
      const { data } = await api.get('/plans');
      return data;
    },
  });
}

export function useUsage() {
  return useQuery<UsageStat[]>({
    queryKey: ['usage'],
    queryFn: async () => {
      const { data } = await api.get('/usage');
      return data;
    },
  });
}

// Admin hooks
export function useAdminStats() {
  return useQuery<AdminStats>({
    queryKey: ['admin', 'stats'],
    queryFn: async () => {
      const { data } = await api.get('/admin/stats');
      return data;
    },
  });
}

export function useAdminUsers(page = 1, search = '') {
  return useQuery<{ users: User[]; total: number }>({
    queryKey: ['admin', 'users', page, search],
    queryFn: async () => {
      const { data } = await api.get('/admin/users', { params: { page, limit: 20, search } });
      return data;
    },
  });
}

export function useUpdateUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, role, tier }: { id: number; role?: string; tier?: string }) => {
      const { data } = await api.put(`/admin/users/${id}`, { role, tier });
      return data as User;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'users'] }),
  });
}

export function useApiConfigs() {
  return useQuery<ApiConfig[]>({
    queryKey: ['admin', 'api-configs'],
    queryFn: async () => {
      const { data } = await api.get('/admin/api-configs');
      return data;
    },
  });
}

export function useCreateApiConfig() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (config: { feature: string; provider: string; model: string; apiKey?: string }) => {
      const { data } = await api.post('/admin/api-configs', config);
      return data as ApiConfig;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'api-configs'] }),
  });
}

export function useDeleteApiConfig() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      await api.delete(`/admin/api-configs/${id}`);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'api-configs'] }),
  });
}

export function useUpdatePlan() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ tier, name, price }: { tier: string; name?: string; price?: string }) => {
      const { data } = await api.put(`/admin/plans/${tier}`, { name, price });
      return data as Plan;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['plans'] }),
  });
}

export function useAdminLogs(page = 1) {
  return useQuery<{ logs: ActivityLog[]; total: number }>({
    queryKey: ['admin', 'logs', page],
    queryFn: async () => {
      const { data } = await api.get('/admin/logs', { params: { page, limit: 20 } });
      return data;
    },
  });
}
