import {
  pgTable,
  serial,
  text,
  timestamp,
  integer,
  boolean,
  numeric,
  pgEnum,
} from 'drizzle-orm/pg-core';

export const roleEnum = pgEnum('role', ['user', 'admin']);
export const tierEnum = pgEnum('tier', ['free', 'pro']);
export const providerEnum = pgEnum('provider', ['groq', 'openai', 'anthropic', 'gemini']);

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  clerkId: text('clerk_id').unique().notNull(),
  email: text('email').unique().notNull(),
  name: text('name'),
  role: text('role', { enum: ['user', 'admin'] }).default('user').notNull(),
  tier: text('tier', { enum: ['free', 'pro'] }).default('free').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const conversations = pgTable('conversations', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  title: text('title').default('New Conversation').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const messages = pgTable('messages', {
  id: serial('id').primaryKey(),
  conversationId: integer('conversation_id').references(() => conversations.id).notNull(),
  role: text('role', { enum: ['user', 'assistant'] }).notNull(),
  content: text('content').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const plans = pgTable('plans', {
  id: serial('id').primaryKey(),
  tier: text('tier').unique().notNull(),
  name: text('name').notNull(),
  price: numeric('price').default('0'),
  features: text('features').array(),
});

export const apiConfigs = pgTable('api_configs', {
  id: serial('id').primaryKey(),
  feature: text('feature').notNull(),
  provider: providerEnum('provider').notNull(),
  model: text('model').notNull(),
  apiKey: text('api_key'),
  isActive: boolean('is_active').default(true).notNull(),
});

export const usage = pgTable('usage', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  feature: text('feature').notNull(),
  count: integer('count').default(0).notNull(),
  resetAt: timestamp('reset_at'),
});

export const activityLogs = pgTable('activity_logs', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  userEmail: text('user_email'),
  type: text('type').notNull(),
  description: text('description').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Conversation = typeof conversations.$inferSelect;
export type NewConversation = typeof conversations.$inferInsert;
export type Message = typeof messages.$inferSelect;
export type NewMessage = typeof messages.$inferInsert;
export type Plan = typeof plans.$inferSelect;
export type ApiConfig = typeof apiConfigs.$inferSelect;
export type NewApiConfig = typeof apiConfigs.$inferInsert;
export type Usage = typeof usage.$inferSelect;
export type ActivityLog = typeof activityLogs.$inferSelect;
