import { defineConfig } from 'orval';

export default defineConfig({
  ulugbekApi: {
    input: {
      target: '../api-spec/openapi.yaml',
    },
    output: {
      mode: 'tags-split',
      target: './src/generated',
      schemas: './src/generated/schemas',
      client: 'react-query',
      httpClient: 'axios',
      override: {
        mutator: {
          path: './src/axios-instance.ts',
          name: 'axiosInstance',
        },
      },
    },
  },
});
