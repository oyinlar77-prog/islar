import { build } from 'esbuild';

await build({
  entryPoints: ['src/index.ts'],
  bundle: true,
  platform: 'node',
  format: 'cjs',
  outfile: 'dist/index.cjs',
  external: ['postgres', 'drizzle-orm', '@clerk/clerk-sdk-node'],
  banner: {
    js: '#!/usr/bin/env node',
  },
});

console.log('Build complete: dist/index.cjs');
