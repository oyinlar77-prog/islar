-- ==================================================
-- ULUGBEK AI - Database Migration Script
-- cPanel PostgreSQL da bu SQL ni ishga tushiring
-- ==================================================

-- Enum types
DO $$ BEGIN
  CREATE TYPE role AS ENUM ('user', 'admin');
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
  CREATE TYPE tier AS ENUM ('free', 'pro');
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
  CREATE TYPE provider AS ENUM ('groq', 'openai', 'anthropic', 'gemini');
EXCEPTION WHEN duplicate_object THEN null; END $$;

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  clerk_id TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  name TEXT,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  tier TEXT NOT NULL DEFAULT 'free' CHECK (tier IN ('free', 'pro')),
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Conversations table
CREATE TABLE IF NOT EXISTS conversations (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  title TEXT NOT NULL DEFAULT 'New Conversation',
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
  id SERIAL PRIMARY KEY,
  conversation_id INTEGER NOT NULL REFERENCES conversations(id),
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
  content TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Plans table
CREATE TABLE IF NOT EXISTS plans (
  id SERIAL PRIMARY KEY,
  tier TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  price NUMERIC DEFAULT 0,
  features TEXT[]
);

-- API Configs table
CREATE TABLE IF NOT EXISTS api_configs (
  id SERIAL PRIMARY KEY,
  feature TEXT NOT NULL,
  provider provider NOT NULL,
  model TEXT NOT NULL,
  api_key TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true
);

-- Usage table
CREATE TABLE IF NOT EXISTS usage (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  feature TEXT NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  reset_at TIMESTAMP
);

-- Activity Logs table
CREATE TABLE IF NOT EXISTS activity_logs (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  user_email TEXT,
  type TEXT NOT NULL,
  description TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Seed default plans
INSERT INTO plans (tier, name, price, features)
VALUES 
  ('free', 'Bepul', 0, ARRAY['Kuniga 10 ta so''rov', 'Asosiy agentlar', 'Suhbat tarixi'])
ON CONFLICT (tier) DO NOTHING;

INSERT INTO plans (tier, name, price, features)
VALUES 
  ('pro', 'Pro', 9.99, ARRAY['Cheklanmagan so''rovlar', 'Barcha agentlar', 'Suhbat tarixi', 'Ustuvor yordam'])
ON CONFLICT (tier) DO NOTHING;
