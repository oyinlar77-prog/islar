import { ClerkExpressWithAuth } from '@clerk/clerk-sdk-node';
import { Request, Response, NextFunction } from 'express';
import { db, users } from './db/index.js';
import { eq } from 'drizzle-orm';
import { logger } from '../logger.js';

// Admin emails - SERVER-SIDE ONLY, never exposed to frontend
const ADMIN_EMAILS = ['tuevulugbek1991@gmail.com', 'globjournal@gmail.com'];

export const clerkAuth = ClerkExpressWithAuth();

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const auth = (req as any).auth;

  if (!auth?.userId) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }
  next();
}

export async function getOrCreateUser(req: Request, res: Response, next: NextFunction) {
  const auth = (req as any).auth;

  if (!auth?.userId) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }

  try {
    let user = await db.select().from(users).where(eq(users.clerkId, auth.userId)).limit(1);

    if (user.length === 0) {
      // JIT provisioning from Clerk session claims
      const sessionClaims = auth.sessionClaims;
      const email = sessionClaims?.email as string || '';
      const name = sessionClaims?.name as string || null;

      const isAdmin = ADMIN_EMAILS.includes(email);

      const [newUser] = await db.insert(users).values({
        clerkId: auth.userId,
        email,
        name,
        role: isAdmin ? 'admin' : 'user',
        tier: 'free',
      }).returning();

      logger.info({ userId: newUser.id, email }, 'New user provisioned');
      (req as any).user = newUser;
    } else {
      // Check if email now matches admin list (for existing users)
      const existingUser = user[0];
      if (ADMIN_EMAILS.includes(existingUser.email) && existingUser.role !== 'admin') {
        const [updatedUser] = await db.update(users)
          .set({ role: 'admin' })
          .where(eq(users.id, existingUser.id))
          .returning();
        (req as any).user = updatedUser;
      } else {
        (req as any).user = existingUser;
      }
    }

    next();
  } catch (error) {
    logger.error(error, 'Error in getOrCreateUser');
    res.status(500).json({ error: 'Internal server error' });
  }
}

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const user = (req as any).user;
  if (!user || user.role !== 'admin') {
    res.status(403).json({ error: 'Forbidden' });
    return;
  }
  next();
}
