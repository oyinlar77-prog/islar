import { Router } from 'express';
import { db, users, usage } from '../db/index.js';
import { eq } from 'drizzle-orm';

const router = Router();

// GET /api/me
router.get('/me', async (req, res) => {
  const user = (req as any).user;
  res.json({
    id: user.id,
    clerkId: user.clerkId,
    email: user.email,
    name: user.name,
    role: user.role,
    tier: user.tier,
    createdAt: user.createdAt,
  });
});

// GET /api/usage
router.get('/usage', async (req, res) => {
  const user = (req as any).user;
  const stats = await db.select().from(usage).where(eq(usage.userId, user.id));
  res.json(stats);
});

export default router;
