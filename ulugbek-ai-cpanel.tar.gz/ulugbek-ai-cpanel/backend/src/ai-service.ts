import { db, apiConfigs, messages, activityLogs } from '../db/index.js';
import { eq, and } from 'drizzle-orm';
import { logger } from '../logger.js';
import Groq from 'groq-sdk';
import OpenAI from 'openai';

type ChatMessage = { role: 'user' | 'assistant'; content: string };

const AGENT_PROMPTS: Record<string, string> = {
  chat: "Sen Ulug'bek AI — foydalanuvchining aqlli yordamchisi. O'zbek tilida javob ber.",
  code: "Sen ekspert dasturchi. Kodlarni to'g'ri formatda yoz. O'zbek tilida javob ber.",
  bank: "Sen bank operatorisan. Moliyaviy masalalarda yordam ber. O'zbek tilida javob ber.",
  gov: "Sen davlat xizmatlari ekspertisan. Rasmiy ma'lumot ber. O'zbek tilida javob ber.",
  doctor: "Sen tibbiy ma'lumot beruvchi mutaxassis. O'zbek tilida javob ber.",
  lawyer: "Sen huquqiy maslahatchi. O'zbekiston qonunlari bo'yicha maslahat ber. O'zbek tilida javob ber.",
  translate: "Sen tarjimonsan. Berilgan matnni ko'rsatilgan tilga tarjima qil.",
  social: "Sen SMM mutaxassis. Ijtimoiy tarmoqlar uchun kontent yarat. O'zbek tilida javob ber.",
  money: "Sen online pul ishlash ekspertisan. Foydali usullar haqida ma'lumot ber. O'zbek tilida javob ber.",
  edu: "Sen sabr-toqatli o'qituvchi. Tushunarli va sodda tilda tushuntir. O'zbek tilida javob ber.",
};

export async function callAI(
  msgs: ChatMessage[],
  agentId: string = 'chat',
  userId?: number
): Promise<string> {
  // Fetch active config for chat feature
  const configs = await db
    .select()
    .from(apiConfigs)
    .where(and(eq(apiConfigs.feature, 'chat'), eq(apiConfigs.isActive, true)))
    .limit(1);

  if (configs.length === 0) {
    throw new Error('No active AI config found. Please configure an AI provider in admin panel.');
  }

  const config = configs[0];
  const systemPrompt = AGENT_PROMPTS[agentId] || AGENT_PROMPTS.chat;

  const systemMsg = { role: 'system' as const, content: systemPrompt };
  const allMessages = [systemMsg, ...msgs.map(m => ({ role: m.role, content: m.content }))];

  try {
    if (config.provider === 'groq') {
      const client = new Groq({ apiKey: config.apiKey || '' });
      const completion = await client.chat.completions.create({
        model: config.model,
        messages: allMessages,
        max_tokens: 2048,
      });
      return completion.choices[0]?.message?.content || '';
    }

    if (config.provider === 'openai') {
      const client = new OpenAI({ apiKey: config.apiKey || '' });
      const completion = await client.chat.completions.create({
        model: config.model,
        messages: allMessages,
        max_tokens: 2048,
      });
      return completion.choices[0]?.message?.content || '';
    }

    if (config.provider === 'anthropic') {
      // Use native fetch for Anthropic
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': config.apiKey || '',
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: config.model,
          max_tokens: 2048,
          system: systemPrompt,
          messages: msgs.map(m => ({ role: m.role, content: m.content })),
        }),
      });
      const data = await response.json() as any;
      return data.content?.[0]?.text || '';
    }

    if (config.provider === 'gemini') {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${config.model}:generateContent?key=${config.apiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            system_instruction: { parts: [{ text: systemPrompt }] },
            contents: msgs.map(m => ({
              role: m.role === 'assistant' ? 'model' : 'user',
              parts: [{ text: m.content }],
            })),
          }),
        }
      );
      const data = await response.json() as any;
      return data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    }

    throw new Error(`Unsupported provider: ${config.provider}`);
  } catch (error) {
    logger.error(error, 'AI completion error');
    throw error;
  }
}
