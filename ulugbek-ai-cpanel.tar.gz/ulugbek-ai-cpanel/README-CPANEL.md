# Ulugbek AI — cPanel Deploy Qo'llanmasi

## Loyiha tuzilmasi

```
cpanel-deploy/
├── backend/        → Node.js API server (cPanel Node.js App)
├── frontend/       → React frontend (qurib, public_html ga yuklanadi)
└── README-CPANEL.md
```

---

## 1-QADAM: CLERK SOZLASH

1. https://dashboard.clerk.com ga kiring
2. Yangi Application yarating
3. **Publishable Key** va **Secret Key** ni oling
4. Clerk Dashboard → **Domains** → domeiningizni qo'shing

---

## 2-QADAM: POSTGRESQL MA'LUMOTLAR BAZASI

> ⚠️ Ko'pgina cPanel hostlar MySQL beradi, lekin bu loyiha **PostgreSQL** talab qiladi.
> Hostingizda PostgreSQL borligini tekshiring yoki VPS ga ko'chiring.

**PostgreSQL bor bo'lsa:**
1. cPanel → PostgreSQL Databases → Yangi baza yarating, masalan: `ulugbek_ai`
2. Yangi user yarating va unga barcha huquqlar bering
3. `backend/migrate.sql` faylini phpPgAdmin yoki terminal orqali ishga tushiring:
   ```sql
   psql -U db_user -d ulugbek_ai -f migrate.sql
   ```

---

## 3-QADAM: BACKEND O'RNATISH (cPanel Node.js App)

### 3.1 — Fayllarni yuklash
1. `backend/` papkasini ZIP qiling
2. cPanel → File Manager → `home/username/nodejs-app/` papkasiga yuklang va chiqaring

### 3.2 — `.env` fayl yarating
`/home/username/nodejs-app/` ichida `.env` fayl yarating:
```
DATABASE_URL=postgresql://db_user:db_password@localhost:5432/ulugbek_ai
CLERK_PUBLISHABLE_KEY=pk_live_...
CLERK_SECRET_KEY=sk_live_...
FRONTEND_URL=https://sizning-domeningiz.com
NODE_ENV=production
PORT=3000
```

### 3.3 — cPanel → Node.js Apps
1. cPanel → **Setup Node.js App** (yoki **Node.js Selector**)
2. **Create Application** tugmasini bosing:
   - **Node.js version**: 20 yoki 22
   - **Application mode**: Production
   - **Application root**: `nodejs-app`
   - **Application URL**: `api.sizning-domeningiz.com` (yoki subdomain)
   - **Application startup file**: `dist/index.cjs`
3. **Save** tugmasini bosing
4. Terminal ochib quyidagi buyruqlarni bajaring:
   ```bash
   cd ~/nodejs-app
   npm install
   npm run build
   ```
5. **Restart** tugmasini bosing

---

## 4-QADAM: FRONTEND QURIB YUKLASH

Bu qadamni **lokal kompyuteringizda** bajaring (Node.js 18+ o'rnatilgan bo'lishi kerak):

### 4.1 — Paketlarni o'rnating
```bash
cd frontend
npm install
```

### 4.2 — `.env` fayl yarating
`frontend/` papkasida `.env` fayl yarating:
```
VITE_CLERK_PUBLISHABLE_KEY=pk_live_...
VITE_API_URL=https://api.sizning-domeningiz.com
```

### 4.3 — Build qiling
```bash
npm run build
```
`frontend/dist/` papkasi yaratiladi.

### 4.4 — cPanel ga yuklang
1. `frontend/dist/` ichidagi **barcha fayllarni** `public_html/` ga yuklang
2. `frontend/public/.htaccess` ni ham `public_html/` ga yuklang

---

## 5-QADAM: CLERK DOMAIN SOZLASH

Clerk Dashboard ga qayting:
1. **Domains** → Production domain qo'shing: `sizning-domeningiz.com`
2. **Allowed redirect URLs** ga qo'shing:
   - `https://sizning-domeningiz.com`
   - `https://sizning-domeningiz.com/chat`
   - `https://sizning-domeningiz.com/admin`
   - `https://sizning-domeningiz.com/settings`

---

## XATO BO'LSA

| Xato | Yechim |
|------|--------|
| `DATABASE_URL` xatosi | `.env` fayl to'g'ri yo'ldami tekshiring |
| Clerk auth ishlamaydi | Clerk Dashboard → Domain ro'yxatda bormi? |
| Frontend "404" ko'rsatadi | `.htaccess` `public_html/` da bormi? |
| API ishlamaydi | cPanel → Node.js App → Restart |

---

## ADMIN PANEL

Birinchi login qilgandan keyin admin huquqi berish uchun:
`backend/src/middleware/auth.ts` faylida emailingizni qo'shing:
```typescript
const ADMIN_EMAILS = ['sizning@email.com'];
```
Keyin qayta build qiling.
